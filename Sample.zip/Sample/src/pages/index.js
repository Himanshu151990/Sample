// import Board from "../Components/square";


export default function IndexPage() {
  return (<>
    <div>

      {/* <Board /> */}
    </div>
  </>);
}

